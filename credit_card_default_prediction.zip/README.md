# Credit Card Default Prediction

This project predicts whether a credit card holder will default on payment next month.

## Files
- `credit_card_prediction.ipynb` : Jupyter Notebook with model code.
- `credit_card_data.csv` : Dataset used.
- `requirements.txt` : Required Python libraries.

## How to Run
1. Open the notebook in Google Colab or Jupyter Notebook.
2. Run all cells to train and test the model.
